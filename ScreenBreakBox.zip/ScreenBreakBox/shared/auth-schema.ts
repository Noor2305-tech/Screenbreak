import { pgTable, varchar, text, boolean, timestamp, serial } from "drizzle-orm/pg-core";
import { users } from "./schema";

// Authentication and security tables
export const userPasswords = pgTable("user_passwords", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  hashedPassword: text("hashed_password").notNull(),
  salt: text("salt").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const userSessions = pgTable("user_sessions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  sessionToken: text("session_token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  ipAddress: varchar("ip_address"),
  userAgent: text("user_agent"),
  isActive: boolean("is_active").default(true),
});

export const userTwoFactor = pgTable("user_two_factor", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  secret: text("secret").notNull(),
  isEnabled: boolean("is_enabled").default(false),
  backupCodes: text("backup_codes").array(),
  lastUsed: timestamp("last_used"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userPaymentMethods = pgTable("user_payment_methods", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  stripePaymentMethodId: text("stripe_payment_method_id").notNull(),
  type: varchar("type").notNull(), // 'card', 'apple_pay', 'google_pay'
  last4: varchar("last4"),
  brand: varchar("brand"), // 'visa', 'mastercard', 'amex', etc.
  expiryMonth: varchar("expiry_month"),
  expiryYear: varchar("expiry_year"),
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userAddresses = pgTable("user_addresses", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: varchar("type").notNull(), // 'billing', 'shipping'
  firstName: varchar("first_name").notNull(),
  lastName: varchar("last_name").notNull(),
  company: varchar("company"),
  address1: text("address1").notNull(),
  address2: text("address2"),
  city: varchar("city").notNull(),
  state: varchar("state").notNull(),
  zipCode: varchar("zip_code").notNull(),
  country: varchar("country").notNull().default('US'),
  phone: varchar("phone"),
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userSecurityLogs = pgTable("user_security_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  action: varchar("action").notNull(), // 'login', 'logout', 'password_change', 'email_change', '2fa_enable', etc.
  ipAddress: varchar("ip_address"),
  userAgent: text("user_agent"),
  location: varchar("location"), // City, State, Country
  timestamp: timestamp("timestamp").defaultNow(),
  success: boolean("success").default(true),
  details: text("details"),
});

export type UserPassword = typeof userPasswords.$inferSelect;
export type UserSession = typeof userSessions.$inferSelect;
export type UserTwoFactor = typeof userTwoFactor.$inferSelect;
export type UserPaymentMethod = typeof userPaymentMethods.$inferSelect;
export type UserAddress = typeof userAddresses.$inferSelect;
export type UserSecurityLog = typeof userSecurityLogs.$inferSelect;

export type InsertUserPassword = typeof userPasswords.$inferInsert;
export type InsertUserSession = typeof userSessions.$inferInsert;
export type InsertUserTwoFactor = typeof userTwoFactor.$inferInsert;
export type InsertUserPaymentMethod = typeof userPaymentMethods.$inferInsert;
export type InsertUserAddress = typeof userAddresses.$inferInsert;
export type InsertUserSecurityLog = typeof userSecurityLogs.$inferInsert;