import { db } from "./db";
import { activities, badges } from "@shared/schema";

export async function seedDatabase() {
  // Clear existing data
  await db.delete(activities);
  await db.delete(badges);

  // Generate comprehensive activities database
  const generateActivities = () => {
    const activities = [];
    
    // Science activities (150 activities)
    const scienceActivities = [
      "Magic Milk Experiment", "Volcano Eruption", "Crystal Growing Garden", "Rainbow in a Glass", "Dancing Raisins",
      "Invisible Ink Messages", "Homemade Lava Lamp", "Static Electricity Balloon", "Color Changing Flowers",
      "Egg in a Bottle", "Floating Egg Experiment", "pH Color Indicators", "Magnetic Slime", "Density Tower",
      "Chromatography Coffee Filters", "Baking Soda Rockets", "Oobleck Non-Newtonian Fluid", "Elephant Toothpaste",
      "Rubber Egg Experiment", "Cartesian Diver", "Homemade Compass", "Weather Station", "Plant Growth Experiment",
      "Electromagnet Creation", "Solar Oven Building", "Water Cycle in a Bag", "Tornado in a Bottle", "Fossil Making",
      "Seed Germination Study", "pH Testing Kit", "Chromatography Experiment", "Density Comparison", "Magnetism Study",
      "Sound Wave Visualization", "Light Refraction", "Prism Rainbow", "Mirror Reflection", "Shadow Play",
      "Pendulum Motion", "Gravity Experiment", "Friction Testing", "Heat Transfer", "Evaporation Study",
      "Condensation Observation", "Sublimation Demo", "States of Matter", "Chemical Reactions", "Acid Base Testing",
      "Enzyme Activity", "Photosynthesis Demo", "Respiration Study", "Digestion Model", "Circulation System",
      "Cell Structure Model", "DNA Extraction", "Bacterial Culture", "Microscopy Lab", "Blood Type Testing",
      "Fingerprint Analysis", "Bone Density Test", "Lung Capacity", "Heart Rate Monitor", "Reflex Testing",
      "Brain Wave Study", "Memory Experiments", "Taste Bud Mapping", "Vision Testing", "Hearing Range",
      "Smell Identification", "Touch Sensitivity", "Balance Testing", "Coordination Games", "Reaction Time",
      "Optical Illusions", "Color Blindness Test", "Depth Perception", "Peripheral Vision", "Night Vision",
      "Solar System Model", "Moon Phases", "Star Constellation", "Planet Rotation", "Gravity Simulation",
      "Rocket Launch", "Satellite Tracking", "Meteorite Hunt", "Comet Observation", "Eclipse Viewing",
      "Weather Prediction", "Cloud Formation", "Rain Gauge", "Wind Speed", "Barometer Reading",
      "Thermometer Use", "Humidity Measurement", "UV Index", "Air Quality Test", "Pollution Study",
      "Renewable Energy", "Solar Panel", "Wind Turbine", "Hydroelectric", "Geothermal Heat",
      "Fossil Fuel Study", "Carbon Footprint", "Recycling Process", "Composting System", "Water Filtration",
      "Ecosystem Study", "Food Chain", "Predator Prey", "Symbiosis Examples", "Adaptation Study",
      "Animal Behavior", "Plant Lifecycle", "Seed Dispersal", "Pollination Process", "Habitat Creation",
      "Biodiversity Count", "Species Classification", "Animal Tracking", "Bird Migration", "Insect Study",
      "Aquatic Life", "Marine Biology", "Coral Reef", "Ocean Currents", "Tide Pools",
      "Geology Rocks", "Mineral Identification", "Sediment Layers", "Erosion Study", "Landform Creation",
      "Earthquake Simulation", "Volcanic Activity", "Plate Tectonics", "Rock Cycle", "Soil Testing",
      "Water Cycle", "River Formation", "Glacier Movement", "Desert Ecosystem", "Rainforest Study",
      "Arctic Environment", "Tundra Life", "Grassland Study", "Mountain Ecosystem", "Cave Exploration",
      "Archaeological Dig", "Artifact Study", "Timeline Creation", "Cultural Exchange", "Language Study",
      "Code Breaking", "Cipher Creation", "Secret Messages", "Pattern Recognition", "Logic Puzzles",
      "Problem Solving", "Critical Thinking", "Hypothesis Testing", "Data Collection", "Result Analysis",
      "Scientific Method", "Observation Skills", "Measurement Tools", "Lab Safety", "Equipment Care",
      "Research Methods", "Information Sources", "Fact Checking", "Peer Review", "Scientific Writing",
      "Presentation Skills", "Public Speaking", "Demonstration", "Teaching Others", "Knowledge Sharing",
      "Innovation Projects", "Invention Process", "Patent Research", "Technology History", "Future Predictions",
      "Robotics Basics", "AI Concepts", "Computer Science", "Programming Logic", "Algorithm Design",
      "Data Structures", "Database Systems", "Network Basics", "Internet Safety", "Digital Citizenship",
      "Social Media", "Online Research", "Information Literacy", "Media Literacy", "Communication Skills",
      "Collaboration Tools", "Project Management", "Time Management", "Goal Setting", "Achievement Tracking",
      "Self Assessment", "Peer Evaluation", "Feedback Systems", "Improvement Planning", "Skill Development",
      "Career Exploration", "Job Shadowing", "Interview Skills", "Resume Building", "Portfolio Creation",
      "Entrepreneurship", "Business Planning", "Market Research", "Customer Service", "Sales Techniques",
      "Financial Literacy", "Budgeting Basics", "Saving Strategies", "Investment Concepts", "Economic Systems",
      "Global Awareness", "Cultural Diversity", "Language Learning", "Travel Planning", "Geography Skills",
      "Map Reading", "Navigation Tools", "Compass Use", "GPS Systems", "Location Services",
      "Emergency Preparedness", "First Aid", "Safety Protocols", "Risk Assessment", "Hazard Identification",
      "Health Monitoring", "Nutrition Study", "Exercise Science", "Mental Health", "Stress Management",
      "Mindfulness Practice", "Meditation Techniques", "Breathing Exercises", "Relaxation Methods", "Sleep Hygiene"
    ];
    
    // Math activities (100 activities)
    const mathActivities = [
      "Fraction Pizza Party", "Geometry Shapes Hunt", "Measurement Kitchen", "Pattern Block Designs", "Number Line Hop",
      "Math Bingo Games", "Counting Collections", "Symmetry Art", "Graphing Weather", "Time Telling Games",
      "Money Counting Store", "Probability Dice", "Statistics Survey", "Area Measurement", "Volume Experiments",
      "Perimeter Walk", "Angle Scavenger Hunt", "Coordinate Grid Art", "Multiplication Arrays", "Division Stories",
      "Decimal Place Value", "Percentage Pizza", "Ratio Recipes", "Proportion Problems", "Algebraic Patterns",
      "Function Machines", "Equation Balancing", "Word Problem Theater", "Math Journal Writing", "Calculator Games",
      "Estimation Jars", "Rounding Races", "Prime Number Hunt", "Factor Trees", "Multiple Madness",
      "Fibonacci Flowers", "Pascal's Triangle", "Magic Squares", "Sudoku Puzzles", "Tangram Challenges",
      "Origami Geometry", "Tessellation Art", "Golden Ratio", "Pi Day Activities", "Math History Timeline",
      "Ancient Number Systems", "Math in Nature", "Architecture Angles", "Sports Statistics", "Cooking Fractions",
      "Base Number Systems", "Binary Counting", "Hexadecimal Fun", "Roman Numerals", "Egyptian Numbers",
      "Mayan Calendar", "Chinese Abacus", "Japanese Soroban", "Russian Abacus", "Mental Math Tricks",
      "Speed Calculations", "Estimation Games", "Approximation Skills", "Order of Operations", "PEMDAS Practice",
      "Algebraic Thinking", "Variable Games", "Equation Solving", "Graphing Lines", "Slope Calculations",
      "Y-Intercept Finding", "System of Equations", "Quadratic Functions", "Parabola Graphing", "Exponential Growth",
      "Logarithmic Functions", "Trigonometry Basics", "Sine Wave Patterns", "Cosine Applications", "Tangent Ratios",
      "Pythagorean Theorem", "Right Triangle Solving", "Special Right Triangles", "Law of Sines", "Law of Cosines",
      "Circle Geometry", "Arc Length", "Sector Area", "Chord Properties", "Tangent Lines",
      "Polygon Properties", "Regular Polygons", "Irregular Shapes", "Congruent Figures", "Similar Triangles",
      "Scale Factors", "Proportional Reasoning", "Cross Multiplication", "Unit Rates", "Rate Problems",
      "Distance Speed Time", "Work Rate Problems", "Mixture Problems", "Age Problems", "Coin Problems",
      "Percentage Applications", "Simple Interest", "Compound Interest", "Profit and Loss", "Discount Calculations",
      "Tax Calculations", "Tip Calculations", "Commission Problems", "Markup Markdown", "Break Even Analysis",
      "Data Analysis", "Mean Median Mode", "Range Calculations", "Standard Deviation", "Variance Analysis",
      "Correlation Studies", "Regression Analysis", "Scatter Plots", "Box Plots", "Histograms",
      "Frequency Tables", "Probability Trees", "Combinations", "Permutations", "Factorial Calculations",
      "Binomial Probability", "Normal Distribution", "Z-Score Calculations", "Confidence Intervals", "Hypothesis Testing"
    ];
    
    // Physics activities (100 activities)
    const physicsActivities = [
      "Paper Airplane Challenge", "Pendulum Swing", "Lever Systems", "Pulley Mechanisms", "Inclined Planes",
      "Wheel and Axle", "Screw Mechanics", "Wedge Demonstrations", "Force and Motion", "Newton's Laws",
      "Momentum Conservation", "Energy Transformations", "Simple Machines", "Magnetic Fields", "Electric Circuits",
      "Sound Waves", "Light Behavior", "Reflection Studies", "Refraction Experiments", "Optics Exploration",
      "Heat Transfer", "Thermal Expansion", "Conduction Examples", "Convection Currents", "Radiation Effects",
      "Pressure Demonstrations", "Buoyancy Tests", "Density Comparisons", "Fluid Dynamics", "Bernoulli's Principle",
      "Aerodynamics Study", "Projectile Motion", "Circular Motion", "Rotational Dynamics", "Oscillations",
      "Wave Properties", "Frequency Analysis", "Amplitude Studies", "Wavelength Measurement", "Interference Patterns",
      "Diffraction Effects", "Polarization", "Electromagnetic Spectrum", "Radio Waves", "Microwaves",
      "Infrared Radiation", "Visible Light", "Ultraviolet Light", "X-rays", "Gamma Rays"
    ];
    
    // Arts & Crafts activities (150 activities)
    const artActivities = [
      "Nature Collage Art", "Painted Rock Garden", "Friendship Bracelets", "Paper Plate Masks", "Cardboard Sculptures",
      "Finger Painting Fun", "Watercolor Techniques", "Crayon Resist Art", "Scratch Art Designs", "Stained Glass Windows",
      "Tissue Paper Flowers", "Origami Animals", "Paper Quilling", "Scrapbook Pages", "Photo Collages",
      "String Art Patterns", "Bead Jewelry", "Clay Pottery", "Modeling Clay", "Salt Dough Crafts",
      "Yarn Painting", "Fabric Dyeing", "Tie-Dye Shirts", "Batik Designs", "Screen Printing",
      "Block Printing", "Stamp Making", "Stencil Art", "Spray Painting", "Acrylic Pouring",
      "Mixed Media Art", "Collage Techniques", "Mosaic Designs", "Tile Art", "Glass Painting",
      "Wood Burning", "Leather Crafting", "Macrame Projects", "Knitting Basics", "Crocheting Fun",
      "Embroidery Stitches", "Cross Stitch", "Applique Work", "Quilting Squares", "Patchwork Designs",
      "Weaving Patterns", "Basket Making", "Pottery Glazing", "Ceramic Painting", "Sculpture Techniques"
    ];
    
    const categories = ["Science", "Math", "Physics", "Arts & Crafts"];
    const ageRanges = ["4-6", "7-12"];
    const difficulties = ["Easy", "Medium", "Hard"];
    const durations = [15, 30, 45, 60, 90];
    
    // Combine all activity names
    const allActivities = [...scienceActivities, ...mathActivities, ...physicsActivities, ...artActivities];
    
    allActivities.forEach((title, index) => {
      const category = index < 150 ? "Science" : 
                     index < 250 ? "Math" : 
                     index < 350 ? "Physics" : "Arts & Crafts";
      
      const materials = category === "Science" ? ["Baking soda", "Vinegar", "Food coloring", "Test tubes", "Magnifying glass"] :
                       category === "Math" ? ["Paper", "Pencil", "Ruler", "Calculator", "Dice"] :
                       category === "Physics" ? ["Paper", "Tape", "Ruler", "String", "Weights"] :
                       ["Paper", "Glue", "Markers", "Scissors", "Colored paper"];
      
      activities.push({
        title,
        description: `Engaging ${category.toLowerCase()} activity that promotes hands-on learning and creativity`,
        instructions: `1. Gather all materials\n2. Follow step-by-step guide\n3. Observe and record results\n4. Discuss findings\n5. Clean up workspace`,
        category,
        ageRange: ageRanges[index % 2],
        duration: durations[index % 5],
        difficulty: difficulties[index % 3],
        materials,
        isPremium: index % 3 === 0, // Every 3rd activity is premium
        imageUrl: null
      });
    });
    
    return activities;
  };
  
  const sampleActivities = generateActivities();

  await db.insert(activities).values(sampleActivities);

  // Seed badges
  const sampleBadges = [
    {
      name: "Science Explorer",
      description: "Complete 5 science activities",
      icon: "🔬",
      category: "Science",
      color: "#3B82F6",
      requirement: 5
    },
    {
      name: "Math Wizard",
      description: "Complete 3 math activities",
      icon: "🧮",
      category: "Math",
      color: "#EF4444",
      requirement: 3
    },
    {
      name: "Physics Pioneer",
      description: "Complete 3 physics activities",
      icon: "⚡",
      category: "Physics",
      color: "#F59E0B",
      requirement: 3
    },
    {
      name: "Creative Artist",
      description: "Complete 5 arts & crafts activities",
      icon: "🎨",
      category: "Arts & Crafts",
      color: "#10B981",
      requirement: 5
    },
    {
      name: "Activity Starter",
      description: "Complete your first activity",
      icon: "🌟",
      category: "General",
      color: "#8B5CF6",
      requirement: 1
    },
    {
      name: "Dedicated Learner",
      description: "Complete 10 activities",
      icon: "📚",
      category: "General",
      color: "#F97316",
      requirement: 10
    }
  ];

  await db.insert(badges).values(sampleBadges);

  console.log("Database seeded successfully!");
}