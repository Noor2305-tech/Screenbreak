import {
  users,
  activities,
  badges,
  userProgress,
  userBadges,
  type User,
  type UpsertUser,
  type Activity,
  type InsertActivity,
  type Badge,
  type InsertBadge,
  type UserProgress,
  type InsertUserProgress,
  type UserBadge,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserSubscription(userId: string, tier: "digital" | "premium" | null, status: "active" | "canceled" | "expired" | null, expiresAt?: Date): Promise<void>;
  
  // Activity operations
  getActivities(filters?: { category?: string; ageRange?: string; isPremium?: boolean }): Promise<Activity[]>;
  getActivity(id: number): Promise<Activity | undefined>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  updateActivity(id: number, activity: Partial<InsertActivity>): Promise<Activity>;
  deleteActivity(id: number): Promise<void>;
  
  // Badge operations
  getBadges(): Promise<Badge[]>;
  createBadge(badge: InsertBadge): Promise<Badge>;
  
  // Progress operations
  getUserProgress(userId: string): Promise<(UserProgress & { activity: Activity })[]>;
  completeActivity(progress: InsertUserProgress): Promise<UserProgress>;
  getUserBadges(userId: string): Promise<(UserBadge & { badge: Badge })[]>;
  checkAndAwardBadges(userId: string): Promise<UserBadge[]>;
  
  // Stats
  getUserStats(userId: string): Promise<{
    totalActivities: number;
    completedActivities: number;
    badgesEarned: number;
    categoryStats: { category: string; count: number }[];
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserSubscription(
    userId: string,
    tier: "digital" | "premium" | null,
    status: "active" | "canceled" | "expired" | null,
    expiresAt?: Date
  ): Promise<void> {
    await db
      .update(users)
      .set({
        subscriptionTier: tier,
        subscriptionStatus: status,
        subscriptionExpiresAt: expiresAt,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  // Activity operations
  async getActivities(filters?: { category?: string; ageRange?: string; isPremium?: boolean }): Promise<Activity[]> {
    let query = db.select().from(activities);
    
    const conditions = [];
    if (filters?.category) {
      conditions.push(eq(activities.category, filters.category));
    }
    if (filters?.ageRange) {
      conditions.push(eq(activities.ageRange, filters.ageRange));
    }
    if (filters?.isPremium !== undefined) {
      conditions.push(eq(activities.isPremium, filters.isPremium));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    const result = await query.orderBy(desc(activities.createdAt));
    return result;
  }

  async getActivity(id: number): Promise<Activity | undefined> {
    const [activity] = await db.select().from(activities).where(eq(activities.id, id));
    return activity;
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [newActivity] = await db.insert(activities).values(activity).returning();
    return newActivity;
  }

  async updateActivity(id: number, activity: Partial<InsertActivity>): Promise<Activity> {
    const [updatedActivity] = await db
      .update(activities)
      .set({ ...activity, updatedAt: new Date() })
      .where(eq(activities.id, id))
      .returning();
    return updatedActivity;
  }

  async deleteActivity(id: number): Promise<void> {
    await db.delete(activities).where(eq(activities.id, id));
  }

  // Badge operations
  async getBadges(): Promise<Badge[]> {
    return db.select().from(badges).orderBy(badges.category, badges.name);
  }

  async createBadge(badge: InsertBadge): Promise<Badge> {
    const [newBadge] = await db.insert(badges).values(badge).returning();
    return newBadge;
  }

  // Progress operations
  async getUserProgress(userId: string): Promise<(UserProgress & { activity: Activity })[]> {
    const result = await db
      .select({
        progress: userProgress,
        activity: activities
      })
      .from(userProgress)
      .leftJoin(activities, eq(userProgress.activityId, activities.id))
      .where(eq(userProgress.userId, userId))
      .orderBy(desc(userProgress.completedAt));
    
    return result.map(row => ({
      ...row.progress,
      activity: row.activity!
    }));
  }

  async completeActivity(progress: InsertUserProgress): Promise<UserProgress> {
    const [newProgress] = await db.insert(userProgress).values(progress).returning();
    
    // Check and award badges after completing activity
    await this.checkAndAwardBadges(progress.userId);
    
    return newProgress;
  }

  async getUserBadges(userId: string): Promise<(UserBadge & { badge: Badge })[]> {
    const result = await db
      .select({
        userBadge: userBadges,
        badge: badges
      })
      .from(userBadges)
      .leftJoin(badges, eq(userBadges.badgeId, badges.id))
      .where(eq(userBadges.userId, userId))
      .orderBy(desc(userBadges.earnedAt));
    
    return result.map(row => ({
      ...row.userBadge,
      badge: row.badge!
    }));
  }

  async checkAndAwardBadges(userId: string): Promise<UserBadge[]> {
    const allBadges = await this.getBadges();
    const userBadgesList = await this.getUserBadges(userId);
    const earnedBadgeIds = userBadgesList.map(ub => ub.badgeId);
    
    const newBadges: UserBadge[] = [];
    
    for (const badge of allBadges) {
      if (earnedBadgeIds.includes(badge.id)) continue;
      
      // Count completed activities in this category
      const [result] = await db
        .select({ count: sql<number>`count(*)` })
        .from(userProgress)
        .leftJoin(activities, eq(userProgress.activityId, activities.id))
        .where(
          and(
            eq(userProgress.userId, userId),
            eq(activities.category, badge.category)
          )
        );
      
      if (result.count >= badge.requirement) {
        const [newBadge] = await db
          .insert(userBadges)
          .values({
            userId,
            badgeId: badge.id,
          })
          .returning();
        newBadges.push(newBadge);
      }
    }
    
    return newBadges;
  }

  async getUserStats(userId: string): Promise<{
    totalActivities: number;
    completedActivities: number;
    badgesEarned: number;
    categoryStats: { category: string; count: number }[];
  }> {
    const [totalActivitiesResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(activities);
    
    const [completedActivitiesResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(userProgress)
      .where(eq(userProgress.userId, userId));
    
    const [badgesResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(userBadges)
      .where(eq(userBadges.userId, userId));
    
    const categoryStats = await db
      .select({
        category: activities.category,
        count: sql<number>`count(*)`,
      })
      .from(userProgress)
      .leftJoin(activities, eq(userProgress.activityId, activities.id))
      .where(eq(userProgress.userId, userId))
      .groupBy(activities.category);
    
    return {
      totalActivities: totalActivitiesResult.count,
      completedActivities: completedActivitiesResult.count,
      badgesEarned: badgesResult.count,
      categoryStats: categoryStats
        .filter(stat => stat.category !== null)
        .map(stat => ({
          category: stat.category as string,
          count: stat.count,
        })),
    };
  }
}

export const storage = new DatabaseStorage();
