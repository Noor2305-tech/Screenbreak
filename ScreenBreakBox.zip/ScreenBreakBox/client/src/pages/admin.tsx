import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { insertActivitySchema, insertBadgeSchema } from "@shared/schema";
import { Settings, Plus, Edit, Trash2, FlaskConical, Calculator, Palette, Atom, Crown, Clock, Users, Star } from "lucide-react";
import type { Activity, Badge as BadgeType } from "@shared/schema";

export default function Admin() {
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);
  const [editingBadge, setEditingBadge] = useState<BadgeType | null>(null);
  const [showActivityDialog, setShowActivityDialog] = useState(false);
  const [showBadgeDialog, setShowBadgeDialog] = useState(false);
  const { toast } = useToast();

  const { data: activities, isLoading: activitiesLoading } = useQuery({
    queryKey: ["/api/activities"],
  });

  const { data: badges, isLoading: badgesLoading } = useQuery({
    queryKey: ["/api/badges"],
  });

  // Activity form
  const activityForm = useForm({
    resolver: zodResolver(insertActivitySchema),
    defaultValues: {
      title: "",
      description: "",
      instructions: "",
      category: "science",
      ageRange: "4-6",
      duration: 30,
      difficulty: "easy",
      materials: [],
      isPremium: false,
      imageUrl: "",
    },
  });

  // Badge form
  const badgeForm = useForm({
    resolver: zodResolver(insertBadgeSchema),
    defaultValues: {
      name: "",
      description: "",
      icon: "fas fa-flask",
      category: "science",
      color: "#FF6B6B",
      requirement: 5,
    },
  });

  const createActivityMutation = useMutation({
    mutationFn: async (data: any) => {
      const materialsArray = typeof data.materials === 'string' 
        ? data.materials.split(',').map((m: string) => m.trim()).filter(Boolean)
        : data.materials;
      
      await apiRequest("POST", "/api/activities", {
        ...data,
        materials: materialsArray,
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Activity created successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      setShowActivityDialog(false);
      activityForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create activity. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateActivityMutation = useMutation({
    mutationFn: async (data: any) => {
      const materialsArray = typeof data.materials === 'string' 
        ? data.materials.split(',').map((m: string) => m.trim()).filter(Boolean)
        : data.materials;
      
      await apiRequest("PUT", `/api/activities/${editingActivity?.id}`, {
        ...data,
        materials: materialsArray,
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Activity updated successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      setShowActivityDialog(false);
      setEditingActivity(null);
      activityForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update activity. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteActivityMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/activities/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Activity deleted successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete activity. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createBadgeMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/badges", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Badge created successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/badges"] });
      setShowBadgeDialog(false);
      badgeForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create badge. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "science": return <FlaskConical className="h-4 w-4" />;
      case "math": return <Calculator className="h-4 w-4" />;
      case "physics": return <Atom className="h-4 w-4" />;
      case "arts_crafts": return <Palette className="h-4 w-4" />;
      default: return <Star className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "science": return "bg-coral text-white";
      case "math": return "bg-sky text-white";
      case "physics": return "bg-soft-purple text-white";
      case "arts_crafts": return "bg-mint text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const handleEditActivity = (activity: Activity) => {
    setEditingActivity(activity);
    activityForm.reset({
      title: activity.title,
      description: activity.description,
      instructions: activity.instructions,
      category: activity.category,
      ageRange: activity.ageRange,
      duration: activity.duration,
      difficulty: activity.difficulty,
      materials: activity.materials,
      isPremium: activity.isPremium,
      imageUrl: activity.imageUrl || "",
    });
    setShowActivityDialog(true);
  };

  const handleEditBadge = (badge: BadgeType) => {
    setEditingBadge(badge);
    badgeForm.reset({
      name: badge.name,
      description: badge.description,
      icon: badge.icon,
      category: badge.category,
      color: badge.color,
      requirement: badge.requirement,
    });
    setShowBadgeDialog(true);
  };

  const onSubmitActivity = (data: any) => {
    if (editingActivity) {
      updateActivityMutation.mutate(data);
    } else {
      createActivityMutation.mutate(data);
    }
  };

  const onSubmitBadge = (data: any) => {
    createBadgeMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center">
            <Settings className="h-8 w-8 mr-3 text-coral" />
            Admin Panel
          </h1>
          <p className="text-gray-600">
            Manage activities, badges, and content for the Adventure Box platform.
          </p>
        </div>

        <Tabs defaultValue="activities" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="activities">Activities</TabsTrigger>
            <TabsTrigger value="badges">Badges</TabsTrigger>
          </TabsList>

          <TabsContent value="activities" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Activities Management</CardTitle>
                  <Dialog open={showActivityDialog} onOpenChange={setShowActivityDialog}>
                    <DialogTrigger asChild>
                      <Button className="bg-coral hover:bg-red-500 text-white">
                        <Plus className="h-4 w-4 mr-2" />
                        Add Activity
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>
                          {editingActivity ? "Edit Activity" : "Add New Activity"}
                        </DialogTitle>
                      </DialogHeader>
                      <Form {...activityForm}>
                        <form onSubmit={activityForm.handleSubmit(onSubmitActivity)} className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={activityForm.control}
                              name="title"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Title</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Activity title" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={activityForm.control}
                              name="category"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Category</FormLabel>
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select category" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="science">Science</SelectItem>
                                      <SelectItem value="math">Math</SelectItem>
                                      <SelectItem value="physics">Physics</SelectItem>
                                      <SelectItem value="arts_crafts">Arts & Crafts</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>

                          <FormField
                            control={activityForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea placeholder="Activity description" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={activityForm.control}
                            name="instructions"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Instructions</FormLabel>
                                <FormControl>
                                  <Textarea placeholder="Step-by-step instructions" rows={4} {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={activityForm.control}
                            name="materials"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Materials (comma-separated)</FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="pipe cleaners, cardboard, glue" 
                                    value={Array.isArray(field.value) ? field.value.join(', ') : field.value}
                                    onChange={(e) => field.onChange(e.target.value)}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <div className="grid grid-cols-3 gap-4">
                            <FormField
                              control={activityForm.control}
                              name="ageRange"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Age Range</FormLabel>
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select age range" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="4-6">4-6 years</SelectItem>
                                      <SelectItem value="7-12">7-12 years</SelectItem>
                                      <SelectItem value="4-12">4-12 years</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={activityForm.control}
                              name="duration"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Duration (minutes)</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="number" 
                                      placeholder="30" 
                                      {...field}
                                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={activityForm.control}
                              name="difficulty"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Difficulty</FormLabel>
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select difficulty" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="easy">Easy</SelectItem>
                                      <SelectItem value="medium">Medium</SelectItem>
                                      <SelectItem value="hard">Hard</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={activityForm.control}
                              name="imageUrl"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Image URL (optional)</FormLabel>
                                  <FormControl>
                                    <Input placeholder="https://example.com/image.jpg" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={activityForm.control}
                              name="isPremium"
                              render={({ field }) => (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value}
                                      onCheckedChange={field.onChange}
                                    />
                                  </FormControl>
                                  <div className="space-y-1 leading-none">
                                    <FormLabel>Premium Activity</FormLabel>
                                    <p className="text-sm text-muted-foreground">
                                      Only available to premium subscribers
                                    </p>
                                  </div>
                                </FormItem>
                              )}
                            />
                          </div>

                          <div className="flex gap-2">
                            <Button
                              type="submit"
                              disabled={createActivityMutation.isPending || updateActivityMutation.isPending}
                              className="bg-coral hover:bg-red-500 text-white"
                            >
                              {editingActivity ? "Update Activity" : "Create Activity"}
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => {
                                setShowActivityDialog(false);
                                setEditingActivity(null);
                                activityForm.reset();
                              }}
                            >
                              Cancel
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {activitiesLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <Skeleton className="h-12 w-12 rounded-lg" />
                        <div className="flex-1 space-y-2">
                          <Skeleton className="h-4 w-3/4" />
                          <Skeleton className="h-3 w-1/2" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {activities?.map((activity: Activity) => (
                      <div key={activity.id} className="flex items-center space-x-4 p-4 border rounded-lg hover:bg-gray-50">
                        <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${getCategoryColor(activity.category)}`}>
                          {getCategoryIcon(activity.category)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <h3 className="font-semibold text-gray-900">{activity.title}</h3>
                            {activity.isPremium && (
                              <Badge variant="outline" className="text-coral border-coral">
                                <Crown className="h-3 w-3 mr-1" />
                                Premium
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{activity.description}</p>
                          <div className="flex items-center space-x-4 text-xs text-gray-500">
                            <div className="flex items-center">
                              <Clock className="h-3 w-3 mr-1" />
                              {activity.duration} min
                            </div>
                            <div className="flex items-center">
                              <Users className="h-3 w-3 mr-1" />
                              Ages {activity.ageRange}
                            </div>
                            <Badge variant="outline" className="capitalize">
                              {activity.difficulty}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditActivity(activity)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deleteActivityMutation.mutate(activity.id)}
                            disabled={deleteActivityMutation.isPending}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="badges" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Badges Management</CardTitle>
                  <Dialog open={showBadgeDialog} onOpenChange={setShowBadgeDialog}>
                    <DialogTrigger asChild>
                      <Button className="bg-sunny hover:bg-yellow-500 text-gray-900">
                        <Plus className="h-4 w-4 mr-2" />
                        Add Badge
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-lg">
                      <DialogHeader>
                        <DialogTitle>Add New Badge</DialogTitle>
                      </DialogHeader>
                      <Form {...badgeForm}>
                        <form onSubmit={badgeForm.handleSubmit(onSubmitBadge)} className="space-y-4">
                          <FormField
                            control={badgeForm.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Badge Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="Science Explorer" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={badgeForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea placeholder="Complete 5 science experiments" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={badgeForm.control}
                              name="category"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Category</FormLabel>
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select category" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="science">Science</SelectItem>
                                      <SelectItem value="math">Math</SelectItem>
                                      <SelectItem value="physics">Physics</SelectItem>
                                      <SelectItem value="arts_crafts">Arts & Crafts</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={badgeForm.control}
                              name="requirement"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Requirement</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="number" 
                                      placeholder="5" 
                                      {...field}
                                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>

                          <div className="flex gap-2">
                            <Button
                              type="submit"
                              disabled={createBadgeMutation.isPending}
                              className="bg-sunny hover:bg-yellow-500 text-gray-900"
                            >
                              Create Badge
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => {
                                setShowBadgeDialog(false);
                                badgeForm.reset();
                              }}
                            >
                              Cancel
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {badgesLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[1, 2, 3, 4].map((i) => (
                      <Card key={i}>
                        <CardContent className="p-6">
                          <div className="flex items-center space-x-4">
                            <Skeleton className="h-12 w-12 rounded-full" />
                            <div className="flex-1 space-y-2">
                              <Skeleton className="h-4 w-32" />
                              <Skeleton className="h-3 w-48" />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {badges?.map((badge: BadgeType) => (
                      <Card key={badge.id}>
                        <CardContent className={`p-6 bg-gradient-to-br ${getCategoryColor(badge.category).replace('text-white', '').replace('bg-', 'from-')} to-opacity-80`}>
                          <div className="flex items-center space-x-4 text-white">
                            <div className="h-12 w-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                              {getCategoryIcon(badge.category)}
                            </div>
                            <div className="flex-1">
                              <h4 className="font-semibold text-lg">{badge.name}</h4>
                              <p className="text-sm opacity-90">{badge.description}</p>
                              <p className="text-xs opacity-75 mt-1">
                                Requirement: {badge.requirement} activities
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
