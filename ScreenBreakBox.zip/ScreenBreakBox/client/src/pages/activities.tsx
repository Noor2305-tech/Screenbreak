import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Clock, Users, Star } from "lucide-react";
import ActivityCard from "@/components/ActivityCard";
import type { Activity } from "@shared/schema";

export default function Activities() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeFilter, setActiveFilter] = useState("all");

  const { data: activities, isLoading } = useQuery({
    queryKey: ["/api/activities"],
  });

  const filters = [
    { id: "all", name: "All Activities", color: "bg-gray-500" },
    { id: "science", name: "Science", color: "bg-coral" },
    { id: "math", name: "Math", color: "bg-sky" },
    { id: "physics", name: "Physics", color: "bg-soft-purple" },
    { id: "arts_crafts", name: "Arts & Crafts", color: "bg-mint" },
  ];

  const ageFilters = [
    { id: "4-6", name: "Ages 4-6" },
    { id: "7-12", name: "Ages 7-12" },
  ];

  const filteredActivities = activities?.filter((activity: Activity) => {
    const matchesSearch = activity.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         activity.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeFilter === "all" || activity.category === activeFilter;
    return matchesSearch && matchesCategory;
  }) || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Activity Library</h1>
          <p className="text-gray-600">
            Hundreds of activities using items you already have at home - pipe cleaners, popsicle sticks, 
            cardboard boxes, and whatever's hiding in your junk drawer.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search activities..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Category Filters */}
          <div className="flex flex-wrap gap-2 mb-4">
            {filters.map((filter) => (
              <Button
                key={filter.id}
                variant={activeFilter === filter.id ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveFilter(filter.id)}
                className={activeFilter === filter.id ? `${filter.color} text-white hover:opacity-90` : ""}
              >
                {filter.name}
              </Button>
            ))}
          </div>

          {/* Age Filters */}
          <div className="flex flex-wrap gap-2">
            {ageFilters.map((filter) => (
              <Badge key={filter.id} variant="outline" className="cursor-pointer hover:bg-gray-100">
                {filter.name}
              </Badge>
            ))}
          </div>
        </div>

        {/* Activities Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <Skeleton className="h-48 w-full" />
                <CardContent className="p-6">
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-1/2" />
                    <Skeleton className="h-16 w-full" />
                    <div className="flex justify-between items-center">
                      <Skeleton className="h-4 w-20" />
                      <Skeleton className="h-8 w-20" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredActivities.map((activity: Activity) => (
                <ActivityCard key={activity.id} activity={activity} />
              ))}
            </div>

            {filteredActivities.length === 0 && (
              <div className="text-center py-12">
                <div className="text-gray-400 mb-4">
                  <Search className="h-12 w-12 mx-auto" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No activities found</h3>
                <p className="text-gray-600">
                  Try adjusting your search terms or filters to find more activities.
                </p>
              </div>
            )}
          </>
        )}

        {/* Load More Button */}
        {!isLoading && filteredActivities.length > 0 && (
          <div className="text-center mt-12">
            <Button size="lg" className="bg-coral hover:bg-red-500 text-white">
              Load More Activities
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
