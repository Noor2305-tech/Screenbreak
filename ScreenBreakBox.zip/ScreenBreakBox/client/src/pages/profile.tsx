import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import BadgeDisplay from "@/components/BadgeDisplay";
import SubscriptionCard from "@/components/SubscriptionCard";
import { User, Trophy, Target, Clock, Calendar } from "lucide-react";

export default function Profile() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/user/stats"],
  });

  const { data: progress, isLoading: progressLoading } = useQuery({
    queryKey: ["/api/user/progress"],
  });

  const { data: userBadges, isLoading: userBadgesLoading } = useQuery({
    queryKey: ["/api/user/badges"],
  });

  const { data: allBadges, isLoading: allBadgesLoading } = useQuery({
    queryKey: ["/api/badges"],
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-coral mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="flex items-center space-x-6">
              <Avatar className="h-24 w-24">
                <AvatarImage src={user.profileImageUrl || ""} alt={user.firstName || ""} />
                <AvatarFallback className="text-2xl">
                  {user.firstName?.[0] || user.email?.[0] || "U"}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  {user.firstName && user.lastName 
                    ? `${user.firstName} ${user.lastName}`
                    : user.firstName || user.email || "Adventurer"}
                </h1>
                <p className="text-gray-600 mb-4">{user.email}</p>
                <div className="flex items-center space-x-6">
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-coral" />
                    <span className="text-sm text-gray-600">
                      {stats?.completedActivities || 0} activities completed
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Trophy className="h-4 w-4 text-sunny" />
                    <span className="text-sm text-gray-600">
                      {stats?.badgesEarned || 0} badges earned
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-sky" />
                    <span className="text-sm text-gray-600">
                      Joined {new Date(user.createdAt || "").toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Activities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                {statsLoading ? (
                  <Skeleton className="h-8 w-16" />
                ) : (
                  <p className="text-2xl font-bold text-gray-900">{stats?.totalActivities || 0}</p>
                )}
                <div className="h-10 w-10 bg-sky/10 rounded-full flex items-center justify-center">
                  <Clock className="h-5 w-5 text-sky" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Completed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                {statsLoading ? (
                  <Skeleton className="h-8 w-16" />
                ) : (
                  <p className="text-2xl font-bold text-gray-900">{stats?.completedActivities || 0}</p>
                )}
                <div className="h-10 w-10 bg-coral/10 rounded-full flex items-center justify-center">
                  <Target className="h-5 w-5 text-coral" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Badges Earned</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                {statsLoading ? (
                  <Skeleton className="h-8 w-16" />
                ) : (
                  <p className="text-2xl font-bold text-gray-900">{stats?.badgesEarned || 0}</p>
                )}
                <div className="h-10 w-10 bg-sunny/10 rounded-full flex items-center justify-center">
                  <Trophy className="h-5 w-5 text-sunny" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Profile Tabs */}
        <Tabs defaultValue="badges" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="badges">Badges</TabsTrigger>
            <TabsTrigger value="activity-history">Activity History</TabsTrigger>
            <TabsTrigger value="subscription">Subscription</TabsTrigger>
          </TabsList>

          <TabsContent value="badges" className="space-y-6">
            {userBadgesLoading || allBadgesLoading ? (
              <div className="space-y-4">
                {[1, 2, 3, 4].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-4">
                        <Skeleton className="h-12 w-12 rounded-full" />
                        <div className="flex-1 space-y-2">
                          <Skeleton className="h-4 w-32" />
                          <Skeleton className="h-3 w-48" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <BadgeDisplay 
                badges={allBadges || []} 
                userBadges={userBadges || []}
                categoryStats={stats?.categoryStats || []}
              />
            )}
          </TabsContent>

          <TabsContent value="activity-history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activities</CardTitle>
              </CardHeader>
              <CardContent>
                {progressLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <div key={i} className="flex items-center space-x-4">
                        <Skeleton className="h-12 w-12 rounded-lg" />
                        <div className="flex-1 space-y-2">
                          <Skeleton className="h-4 w-3/4" />
                          <Skeleton className="h-3 w-1/2" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : progress && progress.length > 0 ? (
                  <div className="space-y-4">
                    {progress.map((item: any) => (
                      <div key={item.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <div className="h-12 w-12 bg-coral/10 rounded-lg flex items-center justify-center">
                          <Target className="h-6 w-6 text-coral" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{item.activity?.title || "Unknown Activity"}</h4>
                          <p className="text-sm text-gray-600">
                            Completed on {new Date(item.completedAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex items-center space-x-1">
                          {[...Array(5)].map((_, i) => (
                            <div
                              key={i}
                              className={`h-4 w-4 ${
                                i < (item.rating || 0) ? 'text-sunny' : 'text-gray-300'
                              }`}
                            >
                              ★
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Target className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No activities completed yet. Start your first adventure!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="subscription" className="space-y-6">
            <SubscriptionCard user={user} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
