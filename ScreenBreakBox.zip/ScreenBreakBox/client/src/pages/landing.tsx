import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shovel, Star, Shield, Clock, Globe, Zap, FlaskConical, Calculator, Palette, Atom, Trophy } from "lucide-react";

export default function Landing() {
  const handleStartTrial = (tier: "digital" | "premium") => {
    // In a real app, this would redirect to payment flow
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <Shovel className="h-8 w-8 text-coral mr-3" />
                <span className="font-bold text-xl text-gray-900">Adventure Box</span>
              </div>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <a href="#how-it-works" className="text-gray-600 hover:text-coral font-medium">How It Works</a>
                <a href="#activities" className="text-gray-600 hover:text-coral font-medium">Activities</a>
                <a href="#pricing" className="text-gray-600 hover:text-coral font-medium">Pricing</a>
                <a href="/api/login" className="text-gray-600 hover:text-coral font-medium">Login</a>
                <Button onClick={() => handleStartTrial("digital")} className="bg-coral hover:bg-red-500 text-white">
                  Start Free Trial
                </Button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-coral to-sky text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="font-bold text-4xl md:text-5xl lg:text-6xl mb-6 leading-tight">
                Turn Screen Time Battles Into <span className="text-sunny">Family Wins</span>
              </h1>
              <p className="text-xl md:text-2xl mb-8 leading-relaxed opacity-90">
                Stop the iPad tantrums. Start the adventure. Weekly activity boxes that get kids excited about screen-free time.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button
                  onClick={() => handleStartTrial("digital")}
                  className="bg-white text-coral hover:bg-gray-100 px-8 py-4 text-lg"
                >
                  Start Your Adventure - $39/month
                </Button>
                <Button
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white hover:text-coral px-8 py-4 text-lg"
                >
                  Watch Demo
                </Button>
              </div>
              <div className="flex items-center gap-6 text-sm">
                <div className="flex items-center">
                  <Star className="h-4 w-4 text-sunny mr-1" />
                  <span>4.9/5 from 2,847 parents</span>
                </div>
                <div className="flex items-center">
                  <Shield className="h-4 w-4 text-mint mr-1" />
                  <span>30-day money back guarantee</span>
                </div>
              </div>
            </div>
            <div className="lg:pl-8">
              <img 
                src="https://images.unsplash.com/photo-1609081219090-a6d81d3085bf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Family doing crafts together" 
                className="rounded-2xl shadow-2xl w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-3xl md:text-4xl text-gray-900 mb-6">
              Sound Familiar?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              You know that moment when you tell your kid to put the iPad down and they act like you just asked them to donate a kidney?
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-red-50 border-red-200">
              <CardContent className="p-6 text-center">
                <div className="h-16 w-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="font-semibold text-xl text-gray-900 mb-3">The Screen Time Battle</h3>
                <p className="text-gray-600">Daily fights over "just 5 more minutes" while you stand there with zero backup plan.</p>
              </CardContent>
            </Card>
            <Card className="bg-yellow-50 border-yellow-200">
              <CardContent className="p-6 text-center">
                <div className="h-16 w-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Globe className="h-8 w-8 text-yellow-500" />
                </div>
                <h3 className="font-semibold text-xl text-gray-900 mb-3">Parent Guilt</h3>
                <p className="text-gray-600">Feeling terrible for using screens as a babysitter, but too exhausted to become a Pinterest mom.</p>
              </CardContent>
            </Card>
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-6 text-center">
                <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-blue-500" />
                </div>
                <h3 className="font-semibold text-xl text-gray-900 mb-3">Craft Supply Chaos</h3>
                <p className="text-gray-600">Crusty Play-Doh harder than concrete and three broken crayons hiding in your junk drawer.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section id="how-it-works" className="py-20 bg-gradient-to-br from-turquoise to-mint text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-4xl md:text-5xl mb-6">
              How Adventure Box Works
            </h2>
            <p className="text-xl opacity-90 max-w-3xl mx-auto">
              Transform "put the iPad away" into "Adventure Box time!" and watch your kids get excited about what's inside.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card className="bg-white text-gray-900">
              <CardContent className="p-8">
                <div className="bg-coral text-white w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold mb-4">1</div>
                <h3 className="font-semibold text-xl mb-3">Weekly Adventure Delivered</h3>
                <p className="text-gray-600">Get new activities every week - either digitally with household items or premium boxes with everything included.</p>
              </CardContent>
            </Card>
            <Card className="bg-white text-gray-900">
              <CardContent className="p-8">
                <div className="bg-sky text-white w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold mb-4">2</div>
                <h3 className="font-semibold text-xl mb-3">30-60 Minutes of Fun</h3>
                <p className="text-gray-600">Each activity is perfectly timed to keep kids engaged while giving parents the break they need.</p>
              </CardContent>
            </Card>
            <Card className="bg-white text-gray-900">
              <CardContent className="p-8">
                <div className="bg-mint text-white w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold mb-4">3</div>
                <h3 className="font-semibold text-xl mb-3">Earn Adventure Badges</h3>
                <p className="text-gray-600">Kids collect digital badges for completing activities, turning screen-free time into a rewarding game.</p>
              </CardContent>
            </Card>
          </div>
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Children doing science experiment" 
                className="rounded-2xl shadow-xl w-full h-auto"
              />
            </div>
            <div>
              <h3 className="font-bold text-2xl mb-6">Learning Disguised as Fun</h3>
              <ul className="space-y-4 text-lg">
                <li className="flex items-start">
                  <FlaskConical className="h-6 w-6 text-sunny mr-3 mt-1 flex-shrink-0" />
                  <span>Science experiments with everyday items</span>
                </li>
                <li className="flex items-start">
                  <Calculator className="h-6 w-6 text-sunny mr-3 mt-1 flex-shrink-0" />
                  <span>Math puzzles that don't feel like homework</span>
                </li>
                <li className="flex items-start">
                  <Atom className="h-6 w-6 text-sunny mr-3 mt-1 flex-shrink-0" />
                  <span>Physics concepts through hands-on play</span>
                </li>
                <li className="flex items-start">
                  <Palette className="h-6 w-6 text-sunny mr-3 mt-1 flex-shrink-0" />
                  <span>Creative arts and crafts adventures</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Badge System Preview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-3xl md:text-4xl text-gray-900 mb-6">
              Adventure Badge System
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Kids love collecting badges, and parents love seeing their children engaged in meaningful activities.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <Card className="bg-gradient-to-br from-coral to-red-500 text-white">
              <CardContent className="p-6 text-center">
                <FlaskConical className="h-12 w-12 mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">Science Explorer</h3>
                <p className="text-sm opacity-90">Complete 5 science experiments</p>
                <div className="mt-4 bg-white bg-opacity-20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full w-3/5"></div>
                </div>
                <p className="text-xs mt-2">3 of 5 completed</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-sky to-blue-500 text-white">
              <CardContent className="p-6 text-center">
                <Calculator className="h-12 w-12 mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">Math Wizard</h3>
                <p className="text-sm opacity-90">Solve 10 math puzzles</p>
                <div className="mt-4 bg-white bg-opacity-20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full w-4/5"></div>
                </div>
                <p className="text-xs mt-2">8 of 10 completed</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-mint to-green-500 text-white">
              <CardContent className="p-6 text-center">
                <Palette className="h-12 w-12 mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">Creative Genius</h3>
                <p className="text-sm opacity-90">Create 3 art projects</p>
                <div className="mt-4 bg-white bg-opacity-20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full w-1/3"></div>
                </div>
                <p className="text-xs mt-2">1 of 3 completed</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-soft-purple to-purple-500 text-white">
              <CardContent className="p-6 text-center">
                <Atom className="h-12 w-12 mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">Physics Master</h3>
                <p className="text-sm opacity-90">Discover 7 physics concepts</p>
                <div className="mt-4 bg-white bg-opacity-20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full w-2/7"></div>
                </div>
                <p className="text-xs mt-2">2 of 7 completed</p>
              </CardContent>
            </Card>
          </div>
          <Card className="bg-gradient-to-r from-sunny to-yellow-400 text-gray-900">
            <CardContent className="p-8 text-center">
              <h3 className="font-bold text-2xl mb-4">
                <Trophy className="inline h-8 w-8 mr-3" />
                Adventure Champion
              </h3>
              <p className="text-lg mb-4">Complete all 4 badge categories to become an Adventure Champion!</p>
              <div className="flex justify-center items-center space-x-4">
                <div className="bg-white bg-opacity-50 rounded-full p-2">
                  <FlaskConical className="h-6 w-6 text-coral" />
                </div>
                <div className="bg-white bg-opacity-50 rounded-full p-2">
                  <Calculator className="h-6 w-6 text-sky" />
                </div>
                <div className="bg-white bg-opacity-50 rounded-full p-2">
                  <Palette className="h-6 w-6 text-mint" />
                </div>
                <div className="bg-white bg-opacity-50 rounded-full p-2">
                  <Atom className="h-6 w-6 text-soft-purple" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-3xl md:text-4xl text-gray-900 mb-6">
              Choose Your Adventure
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Both plans include our badge system, activity library, and transform screen time battles into family wins.
            </p>
          </div>
          <div className="grid lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Digital Plan */}
            <Card className="relative">
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <h3 className="font-bold text-2xl mb-2">Digital Adventures</h3>
                  <p className="text-lg text-gray-600 mb-6">Perfect for DIY families who love creating with household items</p>
                  <div className="mb-6">
                    <span className="text-5xl font-bold text-sky">$39</span>
                    <span className="text-xl text-gray-600">/month</span>
                  </div>
                  <Button 
                    onClick={() => handleStartTrial("digital")}
                    className="bg-sky hover:bg-blue-600 text-white w-full"
                  >
                    Start Free Trial
                  </Button>
                </div>
                <ul className="space-y-4">
                  <li className="flex items-center">
                    <div className="h-5 w-5 bg-sky rounded-full flex items-center justify-center mr-3">
                      <div className="h-2 w-2 bg-white rounded-full"></div>
                    </div>
                    <span>200+ digital activities & printables</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-5 w-5 bg-sky rounded-full flex items-center justify-center mr-3">
                      <div className="h-2 w-2 bg-white rounded-full"></div>
                    </div>
                    <span>Use household items (pipe cleaners, cardboard, etc.)</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-5 w-5 bg-sky rounded-full flex items-center justify-center mr-3">
                      <div className="h-2 w-2 bg-white rounded-full"></div>
                    </div>
                    <span>Digital badge system & progress tracking</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-5 w-5 bg-sky rounded-full flex items-center justify-center mr-3">
                      <div className="h-2 w-2 bg-white rounded-full"></div>
                    </div>
                    <span>New activities added weekly</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-5 w-5 bg-sky rounded-full flex items-center justify-center mr-3">
                      <div className="h-2 w-2 bg-white rounded-full"></div>
                    </div>
                    <span>Printable instruction sheets</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-5 w-5 bg-sky rounded-full flex items-center justify-center mr-3">
                      <div className="h-2 w-2 bg-white rounded-full"></div>
                    </div>
                    <span>Age-appropriate recommendations</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
            
            {/* Premium Plan */}
            <Card className="relative border-2 border-coral">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-sunny text-gray-900 px-4 py-2">Most Popular</Badge>
              </div>
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <h3 className="font-bold text-2xl mb-2">Premium Adventure Box</h3>
                  <p className="text-lg text-gray-600 mb-6">Everything included - no shopping, no prep, just pure adventure</p>
                  <div className="mb-6">
                    <span className="text-5xl font-bold text-coral">$99</span>
                    <span className="text-xl text-gray-600">/month</span>
                  </div>
                  <Button 
                    onClick={() => handleStartTrial("premium")}
                    className="bg-coral hover:bg-red-500 text-white w-full"
                  >
                    Start Free Trial
                  </Button>
                </div>
                <ul className="space-y-4">
                  <li className="flex items-center">
                    <div className="h-5 w-5 bg-coral rounded-full flex items-center justify-center mr-3">
                      <div className="h-2 w-2 bg-white rounded-full"></div>
                    </div>
                    <span>Monthly box with ALL materials included</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-5 w-5 bg-coral rounded-full flex items-center justify-center mr-3">
                      <div className="h-2 w-2 bg-white rounded-full"></div>
                    </div>
                    <span>Everything from Digital Adventures plan</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-5 w-5 bg-coral rounded-full flex items-center justify-center mr-3">
                      <div className="h-2 w-2 bg-white rounded-full"></div>
                    </div>
                    <span>Premium materials & specialized tools</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-5 w-5 bg-coral rounded-full flex items-center justify-center mr-3">
                      <div className="h-2 w-2 bg-white rounded-full"></div>
                    </div>
                    <span>Exclusive premium activities</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-5 w-5 bg-coral rounded-full flex items-center justify-center mr-3">
                      <div className="h-2 w-2 bg-white rounded-full"></div>
                    </div>
                    <span>No prep, no shopping, no stress</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-5 w-5 bg-coral rounded-full flex items-center justify-center mr-3">
                      <div className="h-2 w-2 bg-white rounded-full"></div>
                    </div>
                    <span>Free shipping & returns</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
          <div className="text-center mt-12 space-y-4">
            <p className="text-gray-600 flex items-center justify-center">
              <Shield className="h-5 w-5 text-mint mr-2" />
              30-day money-back guarantee on both plans
            </p>
            <p className="text-gray-600 flex items-center justify-center">
              <div className="h-5 w-5 mr-2 flex items-center justify-center">
                <div className="w-3 h-3 border-2 border-sky rounded-full border-dashed animate-spin"></div>
              </div>
              Cancel anytime, no questions asked
            </p>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-r from-coral to-sky text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-bold text-3xl md:text-4xl mb-6">
            Ready to Transform Screen Time Battles?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of families who've discovered the secret to happy, engaged kids and peaceful parents.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button
              onClick={() => handleStartTrial("digital")}
              className="bg-white text-coral hover:bg-gray-100 px-8 py-4 text-lg"
            >
              Start Your Free Trial - Digital ($39/month)
            </Button>
            <Button
              onClick={() => handleStartTrial("premium")}
              className="bg-sunny text-gray-900 hover:bg-yellow-300 px-8 py-4 text-lg"
            >
              Start Your Free Trial - Premium ($99/month)
            </Button>
          </div>
          <div className="flex justify-center items-center gap-6 text-sm">
            <div className="flex items-center">
              <Star className="h-4 w-4 text-sunny mr-1" />
              <span>4.9/5 from 2,847 parents</span>
            </div>
            <div className="flex items-center">
              <Shield className="h-4 w-4 text-mint mr-1" />
              <span>30-day money back guarantee</span>
            </div>
            <div className="flex items-center">
              <div className="h-4 w-4 mr-1 flex items-center justify-center">
                <div className="w-2 h-2 border border-white rounded-full border-dashed animate-spin"></div>
              </div>
              <span>Cancel anytime</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
