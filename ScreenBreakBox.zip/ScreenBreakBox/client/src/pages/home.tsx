import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Trophy, Target, Clock, Star, FlaskConical, Calculator, Palette, Atom, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import type { Activity, Badge as BadgeType } from "@shared/schema";

export default function Home() {
  const { user } = useAuth();
  
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/user/stats"],
  });

  const { data: recentActivities, isLoading: activitiesLoading } = useQuery({
    queryKey: ["/api/activities"],
  });

  const { data: userBadges, isLoading: badgesLoading } = useQuery({
    queryKey: ["/api/user/badges"],
  });

  const { data: allBadges } = useQuery({
    queryKey: ["/api/badges"],
  });

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 17) return "Good afternoon";
    return "Good evening";
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "science": return <FlaskConical className="h-4 w-4" />;
      case "math": return <Calculator className="h-4 w-4" />;
      case "physics": return <Atom className="h-4 w-4" />;
      case "arts_crafts": return <Palette className="h-4 w-4" />;
      default: return <Star className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "science": return "bg-coral";
      case "math": return "bg-sky";
      case "physics": return "bg-soft-purple";
      case "arts_crafts": return "bg-mint";
      default: return "bg-gray-500";
    }
  };

  const getProgressForBadge = (badge: BadgeType) => {
    if (!stats?.categoryStats) return 0;
    const categoryCount = stats.categoryStats.find(s => s.category === badge.category)?.count || 0;
    return Math.min((categoryCount / badge.requirement) * 100, 100);
  };

  const featuredActivities = recentActivities?.slice(0, 3) || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {getGreeting()}, {user?.firstName || "Adventurer"}! 👋
          </h1>
          <p className="text-gray-600">
            Ready for today's adventure? Let's turn screen time into discovery time!
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Activities Completed</p>
                  {statsLoading ? (
                    <Skeleton className="h-8 w-16 mt-2" />
                  ) : (
                    <p className="text-2xl font-bold text-gray-900">{stats?.completedActivities || 0}</p>
                  )}
                </div>
                <div className="h-12 w-12 bg-coral/10 rounded-full flex items-center justify-center">
                  <Target className="h-6 w-6 text-coral" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Badges Earned</p>
                  {statsLoading ? (
                    <Skeleton className="h-8 w-16 mt-2" />
                  ) : (
                    <p className="text-2xl font-bold text-gray-900">{stats?.badgesEarned || 0}</p>
                  )}
                </div>
                <div className="h-12 w-12 bg-sunny/10 rounded-full flex items-center justify-center">
                  <Trophy className="h-6 w-6 text-sunny" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Activities</p>
                  {statsLoading ? (
                    <Skeleton className="h-8 w-16 mt-2" />
                  ) : (
                    <p className="text-2xl font-bold text-gray-900">{stats?.totalActivities || 0}</p>
                  )}
                </div>
                <div className="h-12 w-12 bg-sky/10 rounded-full flex items-center justify-center">
                  <Clock className="h-6 w-6 text-sky" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Subscription</p>
                  <p className="text-2xl font-bold text-gray-900 capitalize">
                    {user?.subscriptionTier || "None"}
                  </p>
                </div>
                <div className={`h-12 w-12 rounded-full flex items-center justify-center ${
                  user?.subscriptionTier === "premium" ? "bg-coral/10" : "bg-mint/10"
                }`}>
                  <Star className={`h-6 w-6 ${
                    user?.subscriptionTier === "premium" ? "text-coral" : "text-mint"
                  }`} />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Featured Activities */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Featured Activities</span>
                  <Link href="/activities">
                    <Button variant="ghost" size="sm">
                      View All <ArrowRight className="h-4 w-4 ml-1" />
                    </Button>
                  </Link>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {activitiesLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center space-x-4">
                        <Skeleton className="h-16 w-16 rounded-lg" />
                        <div className="flex-1 space-y-2">
                          <Skeleton className="h-4 w-3/4" />
                          <Skeleton className="h-3 w-1/2" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {featuredActivities.map((activity: Activity) => (
                      <div key={activity.id} className="flex items-center space-x-4 p-4 rounded-lg border hover:bg-gray-50 transition-colors">
                        <div className={`h-16 w-16 rounded-lg flex items-center justify-center ${getCategoryColor(activity.category)}`}>
                          <div className="text-white">
                            {getCategoryIcon(activity.category)}
                          </div>
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">{activity.title}</h3>
                          <p className="text-sm text-gray-600 mb-2">{activity.description}</p>
                          <div className="flex items-center space-x-4 text-xs text-gray-500">
                            <span>{activity.duration} min</span>
                            <span>Ages {activity.ageRange}</span>
                            <Badge variant="outline" className="capitalize">
                              {activity.category.replace('_', ' ')}
                            </Badge>
                          </div>
                        </div>
                        <Button size="sm" className="bg-coral hover:bg-red-500">
                          Start
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Badge Progress */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Badge Progress</CardTitle>
              </CardHeader>
              <CardContent>
                {badgesLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Skeleton className="h-4 w-24" />
                          <Skeleton className="h-4 w-12" />
                        </div>
                        <Skeleton className="h-2 w-full" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {allBadges?.map((badge: BadgeType) => {
                      const progress = getProgressForBadge(badge);
                      const isEarned = userBadges?.some((ub: any) => ub.badgeId === badge.id);
                      
                      return (
                        <div key={badge.id} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <div className={`h-6 w-6 rounded-full flex items-center justify-center ${getCategoryColor(badge.category)}`}>
                                <div className="text-white text-xs">
                                  {getCategoryIcon(badge.category)}
                                </div>
                              </div>
                              <span className="text-sm font-medium">{badge.name}</span>
                            </div>
                            <span className="text-xs text-gray-500">
                              {isEarned ? "✓" : `${Math.floor(progress)}%`}
                            </span>
                          </div>
                          <Progress value={progress} className="h-2" />
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
