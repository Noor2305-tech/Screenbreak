import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { FlaskConical, Calculator, Palette, Atom, Star, Trophy } from "lucide-react";
import type { Badge as BadgeType, UserBadge } from "@shared/schema";

interface BadgeDisplayProps {
  badges: BadgeType[];
  userBadges: UserBadge[];
  categoryStats: { category: string; count: number }[];
}

export default function BadgeDisplay({ badges, userBadges, categoryStats }: BadgeDisplayProps) {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "science": return <FlaskConical className="h-6 w-6" />;
      case "math": return <Calculator className="h-6 w-6" />;
      case "physics": return <Atom className="h-6 w-6" />;
      case "arts_crafts": return <Palette className="h-6 w-6" />;
      default: return <Star className="h-6 w-6" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "science": return "from-coral to-red-500";
      case "math": return "from-sky to-blue-500";
      case "physics": return "from-soft-purple to-purple-500";
      case "arts_crafts": return "from-mint to-green-500";
      default: return "from-gray-400 to-gray-500";
    }
  };

  const getProgressForBadge = (badge: BadgeType) => {
    const categoryCount = categoryStats.find(s => s.category === badge.category)?.count || 0;
    return Math.min((categoryCount / badge.requirement) * 100, 100);
  };

  const isEarned = (badgeId: number) => {
    return userBadges.some(ub => ub.badgeId === badgeId);
  };

  const earnedBadges = badges.filter(badge => isEarned(badge.id));
  const inProgressBadges = badges.filter(badge => !isEarned(badge.id));

  return (
    <div className="space-y-8">
      {/* Earned Badges */}
      {earnedBadges.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Trophy className="h-5 w-5 text-sunny mr-2" />
            Earned Badges ({earnedBadges.length})
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {earnedBadges.map((badge) => (
              <Card key={badge.id} className="relative overflow-hidden">
                <div className="absolute top-2 right-2">
                  <Badge className="bg-sunny text-gray-900">✓ Earned</Badge>
                </div>
                <CardContent className={`p-6 bg-gradient-to-br ${getCategoryColor(badge.category)} text-white`}>
                  <div className="flex items-center space-x-4">
                    <div className="h-12 w-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                      {getCategoryIcon(badge.category)}
                    </div>
                    <div>
                      <h4 className="font-semibold text-lg">{badge.name}</h4>
                      <p className="text-sm opacity-90">{badge.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* In Progress Badges */}
      {inProgressBadges.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Badge Progress ({inProgressBadges.length})
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {inProgressBadges.map((badge) => {
              const progress = getProgressForBadge(badge);
              const categoryCount = categoryStats.find(s => s.category === badge.category)?.count || 0;
              
              return (
                <Card key={badge.id}>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4 mb-4">
                      <div className={`h-12 w-12 bg-gradient-to-br ${getCategoryColor(badge.category)} rounded-full flex items-center justify-center text-white`}>
                        {getCategoryIcon(badge.category)}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-lg text-gray-900">{badge.name}</h4>
                        <p className="text-sm text-gray-600">{badge.description}</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">
                          {categoryCount} of {badge.requirement} completed
                        </span>
                        <span className="font-medium">{Math.floor(progress)}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Adventure Champion */}
      <Card className="bg-gradient-to-r from-sunny to-yellow-400">
        <CardContent className="p-8 text-center">
          <h3 className="font-bold text-2xl text-gray-900 mb-4">
            <Trophy className="inline h-8 w-8 mr-3" />
            Adventure Champion
          </h3>
          <p className="text-lg text-gray-800 mb-6">
            Complete all 4 badge categories to become an Adventure Champion!
          </p>
          <div className="flex justify-center items-center space-x-4">
            {['science', 'math', 'arts_crafts', 'physics'].map((category) => {
              const hasEarnedBadge = earnedBadges.some(badge => badge.category === category);
              return (
                <div
                  key={category}
                  className={`h-12 w-12 rounded-full flex items-center justify-center ${
                    hasEarnedBadge
                      ? `bg-gradient-to-br ${getCategoryColor(category)} text-white`
                      : 'bg-white bg-opacity-50 text-gray-400'
                  }`}
                >
                  {getCategoryIcon(category)}
                </div>
              );
            })}
          </div>
          <p className="text-sm text-gray-700 mt-4">
            {earnedBadges.length} of 4 categories completed
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
