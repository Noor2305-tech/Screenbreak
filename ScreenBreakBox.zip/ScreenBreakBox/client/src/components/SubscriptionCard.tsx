import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Crown, Star, Check, X, CreditCard, Calendar, AlertCircle } from "lucide-react";
import type { User } from "@shared/schema";

interface SubscriptionCardProps {
  user: User;
}

export default function SubscriptionCard({ user }: SubscriptionCardProps) {
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const { toast } = useToast();

  const updateSubscriptionMutation = useMutation({
    mutationFn: async (tier: "digital" | "premium") => {
      await apiRequest("POST", "/api/user/subscription", { tier });
    },
    onSuccess: () => {
      toast({
        title: "Subscription Updated",
        description: "Your subscription has been updated successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setShowUpgradeDialog(false);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update subscription. Please try again.",
        variant: "destructive",
      });
    },
  });

  const cancelSubscriptionMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", "/api/user/subscription");
    },
    onSuccess: () => {
      toast({
        title: "Subscription Canceled",
        description: "Your subscription has been canceled successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setShowCancelDialog(false);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to cancel subscription. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleUpgrade = (tier: "digital" | "premium") => {
    updateSubscriptionMutation.mutate(tier);
  };

  const handleCancel = () => {
    cancelSubscriptionMutation.mutate();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const isExpired = user.subscriptionExpiresAt ? new Date(user.subscriptionExpiresAt) < new Date() : false;

  return (
    <div className="space-y-6">
      {/* Current Subscription Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Current Subscription</span>
            {user.subscriptionTier && (
              <Badge 
                className={`${
                  user.subscriptionTier === "premium" 
                    ? "bg-coral text-white" 
                    : "bg-sky text-white"
                } capitalize`}
              >
                {user.subscriptionTier === "premium" ? (
                  <Crown className="h-3 w-3 mr-1" />
                ) : (
                  <Star className="h-3 w-3 mr-1" />
                )}
                {user.subscriptionTier}
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {user.subscriptionTier ? (
            <>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Status</span>
                <Badge 
                  variant={user.subscriptionStatus === "active" ? "default" : "destructive"}
                  className={
                    user.subscriptionStatus === "active" 
                      ? "bg-mint text-white" 
                      : ""
                  }
                >
                  {user.subscriptionStatus}
                </Badge>
              </div>
              
              {user.subscriptionExpiresAt && (
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">
                    {user.subscriptionStatus === "active" ? "Next billing" : "Expires"}
                  </span>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1 text-gray-500" />
                    <span className={isExpired ? "text-red-500" : ""}>
                      {formatDate(user.subscriptionExpiresAt)}
                    </span>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between">
                <span className="text-gray-600">Price</span>
                <span className="font-semibold text-lg">
                  ${user.subscriptionTier === "premium" ? "99" : "39"}/month
                </span>
              </div>

              <div className="flex space-x-2 pt-4">
                {user.subscriptionTier === "digital" && (
                  <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
                    <DialogTrigger asChild>
                      <Button className="bg-coral hover:bg-red-500 text-white">
                        <Crown className="h-4 w-4 mr-2" />
                        Upgrade to Premium
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Upgrade to Premium</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="bg-gradient-to-r from-coral to-red-500 text-white p-6 rounded-lg">
                          <h3 className="font-bold text-xl mb-2">Premium Adventure Box</h3>
                          <p className="text-lg mb-4">$99/month</p>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2" />
                              Monthly box with ALL materials included
                            </li>
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2" />
                              Everything from Digital Adventures plan
                            </li>
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2" />
                              Premium materials & specialized tools
                            </li>
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2" />
                              Exclusive premium activities
                            </li>
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2" />
                              Free shipping & returns
                            </li>
                          </ul>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            onClick={() => handleUpgrade("premium")}
                            disabled={updateSubscriptionMutation.isPending}
                            className="bg-coral hover:bg-red-500 text-white flex-1"
                          >
                            <CreditCard className="h-4 w-4 mr-2" />
                            {updateSubscriptionMutation.isPending ? "Processing..." : "Upgrade Now"}
                          </Button>
                          <Button
                            variant="outline"
                            onClick={() => setShowUpgradeDialog(false)}
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                )}
                
                <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="text-red-500 hover:text-red-700">
                      Cancel Subscription
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle className="flex items-center text-red-500">
                        <AlertCircle className="h-5 w-5 mr-2" />
                        Cancel Subscription
                      </DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <p className="text-sm text-yellow-800">
                          Are you sure you want to cancel your subscription? You'll lose access to:
                        </p>
                        <ul className="mt-2 text-sm text-yellow-700 space-y-1">
                          <li className="flex items-center">
                            <X className="h-3 w-3 mr-2" />
                            {user.subscriptionTier === "premium" ? "Monthly adventure boxes" : "Digital activities"}
                          </li>
                          <li className="flex items-center">
                            <X className="h-3 w-3 mr-2" />
                            Badge system and progress tracking
                          </li>
                          <li className="flex items-center">
                            <X className="h-3 w-3 mr-2" />
                            New weekly activities
                          </li>
                        </ul>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          onClick={handleCancel}
                          disabled={cancelSubscriptionMutation.isPending}
                          variant="destructive"
                          className="flex-1"
                        >
                          {cancelSubscriptionMutation.isPending ? "Canceling..." : "Yes, Cancel"}
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => setShowCancelDialog(false)}
                        >
                          Keep Subscription
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <div className="bg-gray-100 rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4">
                <CreditCard className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No Active Subscription</h3>
              <p className="text-gray-600 mb-6">
                Choose a plan to start your adventure and unlock all activities!
              </p>
              <div className="flex space-x-4">
                <Button
                  onClick={() => handleUpgrade("digital")}
                  disabled={updateSubscriptionMutation.isPending}
                  className="bg-sky hover:bg-blue-600 text-white"
                >
                  Digital - $39/month
                </Button>
                <Button
                  onClick={() => handleUpgrade("premium")}
                  disabled={updateSubscriptionMutation.isPending}
                  className="bg-coral hover:bg-red-500 text-white"
                >
                  Premium - $99/month
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Subscription Comparison */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="relative">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Star className="h-5 w-5 mr-2 text-sky" />
              Digital Adventures
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center mb-4">
              <div className="text-3xl font-bold text-sky mb-2">$39</div>
              <div className="text-gray-600">/month</div>
            </div>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center">
                <Check className="h-4 w-4 mr-2 text-sky" />
                200+ digital activities & printables
              </li>
              <li className="flex items-center">
                <Check className="h-4 w-4 mr-2 text-sky" />
                Use household items
              </li>
              <li className="flex items-center">
                <Check className="h-4 w-4 mr-2 text-sky" />
                Digital badge system
              </li>
              <li className="flex items-center">
                <Check className="h-4 w-4 mr-2 text-sky" />
                Weekly new activities
              </li>
              <li className="flex items-center">
                <Check className="h-4 w-4 mr-2 text-sky" />
                Age-appropriate recommendations
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="relative border-2 border-coral">
          <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
            <Badge className="bg-sunny text-gray-900">Most Popular</Badge>
          </div>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Crown className="h-5 w-5 mr-2 text-coral" />
              Premium Adventure Box
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center mb-4">
              <div className="text-3xl font-bold text-coral mb-2">$99</div>
              <div className="text-gray-600">/month</div>
            </div>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center">
                <Check className="h-4 w-4 mr-2 text-coral" />
                Monthly box with ALL materials
              </li>
              <li className="flex items-center">
                <Check className="h-4 w-4 mr-2 text-coral" />
                Everything from Digital plan
              </li>
              <li className="flex items-center">
                <Check className="h-4 w-4 mr-2 text-coral" />
                Premium materials & tools
              </li>
              <li className="flex items-center">
                <Check className="h-4 w-4 mr-2 text-coral" />
                Exclusive premium activities
              </li>
              <li className="flex items-center">
                <Check className="h-4 w-4 mr-2 text-coral" />
                Free shipping & returns
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
