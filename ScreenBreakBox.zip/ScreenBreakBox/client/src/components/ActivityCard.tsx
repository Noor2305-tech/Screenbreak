import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Clock, Users, Star, FlaskConical, Calculator, Palette, Atom, CheckCircle } from "lucide-react";
import type { Activity } from "@shared/schema";

interface ActivityCardProps {
  activity: Activity;
}

export default function ActivityCard({ activity }: ActivityCardProps) {
  const [isCompleting, setIsCompleting] = useState(false);
  const [rating, setRating] = useState(5);
  const [notes, setNotes] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "science": return <FlaskConical className="h-4 w-4" />;
      case "math": return <Calculator className="h-4 w-4" />;
      case "physics": return <Atom className="h-4 w-4" />;
      case "arts_crafts": return <Palette className="h-4 w-4" />;
      default: return <Star className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "science": return "bg-coral text-white";
      case "math": return "bg-sky text-white";
      case "physics": return "bg-soft-purple text-white";
      case "arts_crafts": return "bg-mint text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const completeActivityMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/user/progress", {
        activityId: activity.id,
        rating,
        notes,
      });
    },
    onSuccess: () => {
      toast({
        title: "Activity Completed!",
        description: `Great job completing "${activity.title}"! Check your badges for any new achievements.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/progress"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/badges"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/stats"] });
      setIsCompleting(false);
      setNotes("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to complete activity. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleComplete = () => {
    completeActivityMutation.mutate();
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="h-48 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
        {activity.imageUrl ? (
          <img 
            src={activity.imageUrl} 
            alt={activity.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className={`h-16 w-16 rounded-full flex items-center justify-center ${getCategoryColor(activity.category)}`}>
            <div className="text-white text-2xl">
              {getCategoryIcon(activity.category)}
            </div>
          </div>
        )}
      </div>
      
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-2">
          <Badge className={`${getCategoryColor(activity.category)} text-xs`}>
            {getCategoryIcon(activity.category)}
            <span className="ml-1 capitalize">{activity.category.replace('_', ' ')}</span>
          </Badge>
          <span className="text-gray-500 text-sm flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            {activity.duration} min
          </span>
        </div>
        
        <h3 className="font-semibold text-lg text-gray-900 mb-2">{activity.title}</h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-3">{activity.description}</p>
        
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center text-gray-500 text-sm">
            <Users className="h-3 w-3 mr-1" />
            <span>Ages {activity.ageRange}</span>
          </div>
          <div className="flex items-center text-gray-500 text-sm">
            <Star className="h-3 w-3 mr-1" />
            <span className="capitalize">{activity.difficulty}</span>
          </div>
        </div>

        <div className="space-y-3">
          <Dialog>
            <DialogTrigger asChild>
              <Button className="w-full bg-coral hover:bg-red-500 text-white">
                Start Activity
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <div className={`h-8 w-8 rounded-full flex items-center justify-center ${getCategoryColor(activity.category)}`}>
                    {getCategoryIcon(activity.category)}
                  </div>
                  {activity.title}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {activity.duration} minutes
                  </div>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-1" />
                    Ages {activity.ageRange}
                  </div>
                  <Badge variant="outline" className="capitalize">
                    {activity.difficulty}
                  </Badge>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Description</h4>
                  <p className="text-gray-600">{activity.description}</p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Materials Needed</h4>
                  <ul className="list-disc list-inside text-gray-600 space-y-1">
                    {activity.materials.map((material, index) => (
                      <li key={index}>{material}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Instructions</h4>
                  <div className="text-gray-600 whitespace-pre-wrap">{activity.instructions}</div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => setIsCompleting(true)}
                    className="flex-1 bg-mint hover:bg-green-500 text-white"
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Complete Activity
                  </Button>
                  <Button variant="outline" className="flex-1">
                    Print Instructions
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          {activity.isPremium && (
            <Badge variant="outline" className="w-full justify-center text-coral border-coral">
              Premium Activity
            </Badge>
          )}
        </div>
      </CardContent>

      {/* Complete Activity Dialog */}
      <Dialog open={isCompleting} onOpenChange={setIsCompleting}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Complete Activity</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="rating">How did it go? (1-5 stars)</Label>
              <div className="flex items-center gap-1 mt-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Button
                    key={star}
                    variant="ghost"
                    size="sm"
                    onClick={() => setRating(star)}
                    className="p-1"
                  >
                    <Star 
                      className={`h-6 w-6 ${star <= rating ? 'text-sunny fill-current' : 'text-gray-300'}`}
                    />
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <Label htmlFor="notes">Notes (optional)</Label>
              <Textarea
                id="notes"
                placeholder="How did your child enjoy this activity? Any modifications you made?"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="mt-2"
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleComplete}
                disabled={completeActivityMutation.isPending}
                className="flex-1 bg-coral hover:bg-red-500 text-white"
              >
                {completeActivityMutation.isPending ? "Completing..." : "Complete Activity"}
              </Button>
              <Button
                variant="outline"
                onClick={() => setIsCompleting(false)}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
